package com.mytrade.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try {
            Intent s = new Intent(c, RingService.class);
            s.putExtras(i);
            c.startForegroundService(s);
        } catch (Exception e) {
            try {
                NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
                NotificationChannel ch = new NotificationChannel("ring_fb", "Alarm backup", NotificationManager.IMPORTANCE_HIGH);
                ch.setSound(null, null);
                ch.enableVibration(true);
                ch.setVibrationPattern(new long[]{0, 700, 500, 700, 500, 700});
                nm.createNotificationChannel(ch);
                Notification n = new Notification.Builder(c, "ring_fb")
                        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                        .setContentTitle(i.getStringExtra("name"))
                        .setContentText(i.getStringExtra("time"))
                        .setCategory(Notification.CATEGORY_ALARM)
                        .setAutoCancel(true)
                        .build();
                nm.notify(2, n);
            } catch (Exception x) {
                // nothing more we can do
            }
        }
        AlarmScheduler.scheduleNext(c);
    }
}
