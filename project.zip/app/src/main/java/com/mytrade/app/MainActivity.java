package com.mytrade.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.os.PowerManager;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.widget.ScrollView;
import android.widget.TextView;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> filePicker;

    private void installCrashReporter() {
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    getSharedPreferences("crash", MODE_PRIVATE).edit().putString("t", sw.toString()).commit();
                } catch (Exception x) {
                    // ignore
                }
                if (old != null) old.uncaughtException(t, e);
            }
        });
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        installCrashReporter();
        final String crash = getSharedPreferences("crash", MODE_PRIVATE).getString("t", null);
        if (crash != null) {
            getSharedPreferences("crash", MODE_PRIVATE).edit().remove("t").commit();
            TextView tv = new TextView(this);
            tv.setText(crash.length() > 3000 ? crash.substring(0, 3000) : crash);
            tv.setTextSize(11);
            tv.setPadding(24, 24, 24, 24);
            ScrollView sv = new ScrollView(this);
            sv.addView(tv);
            new AlertDialog.Builder(this)
                    .setTitle("The app crashed last time. Screenshot this and send it.")
                    .setView(sv)
                    .setCancelable(false)
                    .setPositiveButton("Continue", (d, i) -> recreate())
                    .show();
            return;
        }
        web = new WebView(this);
        web.setFitsSystemWindows(true);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton("OK", (d, i) -> r.confirm())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePicker != null) filePicker.onReceiveValue(null);
                filePicker = cb;
                try {
                    startActivityForResult(p.createIntent(), 77);
                } catch (Exception e) {
                    filePicker.onReceiveValue(null);
                    filePicker = null;
                    return false;
                }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        try {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
            AlarmScheduler.scheduleNext(this);
        } catch (Exception e) {
            // never crash on startup
        }
    }

    private String icon(Drawable d) {
        int s = 72;
        Bitmap bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        d.setBounds(0, 0, s, s);
        d.draw(c);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, bo);
        return "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    public class Bridge {
        @JavascriptInterface
        public void setAlarms(String json) {
            try {
                AlarmScheduler.save(MainActivity.this, json);
                AlarmScheduler.scheduleNext(MainActivity.this);
            } catch (Exception e) {
                // ignore
            }
        }

        @JavascriptInterface
        public String alarmStatus() {
            try {
                JSONObject o = new JSONObject();
                o.put("next", getSharedPreferences(AlarmScheduler.PREF, MODE_PRIVATE).getLong("next", 0));
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                o.put("notif", nm.areNotificationsEnabled());
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                o.put("battery", pm.isIgnoringBatteryOptimizations(getPackageName()));
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void testAlarm() {
            try {
                AlarmScheduler.test(MainActivity.this);
            } catch (Exception e) {
                // ignore
            }
        }

        @JavascriptInterface
        public void openBattery() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                    } catch (Exception x) {
                        // ignore
                    }
                }
            });
        }

        @JavascriptInterface
        public void setBlocker(String json) {
            try {
                Blocker.save(MainActivity.this, json);
            } catch (Exception e) {
                // ignore
            }
        }

        @JavascriptInterface
        public boolean isBlockerReady() {
            try {
                return checkBlocker();
            } catch (Exception e) {
                return false;
            }
        }

        private boolean checkBlocker() {
            String list = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (list == null) return false;
            ComponentName cn = new ComponentName(MainActivity.this, BlockerService.class);
            return list.contains(cn.flattenToString()) || list.contains(cn.flattenToShortString());
        }

        @JavascriptInterface
        public void openAccessibility() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                } catch (Exception e) {
                    // ignore
                }
            });
        }

        @JavascriptInterface
        public String getApps() {
            try {
                return loadApps();
            } catch (Exception e) {
                return "[]";
            }
        }

        private String loadApps() {
            PackageManager pm = getPackageManager();
            Intent mi = new Intent(Intent.ACTION_MAIN);
            mi.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(mi, 0);
            List<JSONObject> out = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (ResolveInfo r : list) {
                String pkg = r.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                try {
                    JSONObject o = new JSONObject();
                    o.put("p", pkg);
                    o.put("n", String.valueOf(r.loadLabel(pm)));
                    o.put("i", icon(r.loadIcon(pm)));
                    out.add(o);
                } catch (Exception e) {
                    // skip this app
                }
            }
            Collections.sort(out, new Comparator<JSONObject>() {
                @Override
                public int compare(JSONObject a, JSONObject b) {
                    return a.optString("n").compareToIgnoreCase(b.optString("n"));
                }
            });
            return new JSONArray(out).toString();
        }
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        if (rq == 77) {
            if (filePicker != null) {
                filePicker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, data));
                filePicker = null;
            }
            return;
        }
        super.onActivityResult(rq, rs, data);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
