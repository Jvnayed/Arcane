package com.mytrade.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;

public class BlockActivity extends Activity {
    private String pkg = "";
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable watch = new Runnable() {
        @Override
        public void run() {
            if (!Blocker.isBlockedNow(BlockActivity.this, pkg)) {
                finish();
                return;
            }
            h.postDelayed(this, 2000);
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        pkg = getIntent().getStringExtra("pkg");
        if (pkg == null) pkg = "";

        String label = pkg;
        ImageView appIcon = new ImageView(this);
        try {
            PackageManager pm = getPackageManager();
            label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
            appIcon.setImageDrawable(pm.getApplicationIcon(pkg));
        } catch (Exception e) {
            // keep the package name
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(40), dp(24), dp(32));
        root.setBackgroundColor(Color.BLACK);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.END);
        TextView x = new TextView(this);
        x.setText("\u2715");
        x.setTextColor(Color.WHITE);
        x.setTextSize(22);
        x.setGravity(Gravity.CENTER);
        GradientDrawable xb = new GradientDrawable();
        xb.setShape(GradientDrawable.OVAL);
        xb.setColor(Color.parseColor("#262626"));
        x.setBackground(xb);
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        });
        top.addView(x, new LinearLayout.LayoutParams(dp(52), dp(52)));
        root.addView(top);

        String custom = Blocker.message(this);
        if (custom.length() > 0) {
            TextView msg = new TextView(this);
            msg.setText(custom);
            msg.setTextColor(Color.WHITE);
            msg.setTextSize(26);
            msg.setTypeface(msg.getTypeface(), Typeface.BOLD);
            msg.setPadding(0, dp(32), 0, 0);
            root.addView(msg, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        } else {
            root.addView(new View(this), new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        }

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(appIcon, new LinearLayout.LayoutParams(dp(56), dp(56)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), 0, 0, 0);
        TextView t1 = new TextView(this);
        t1.setTextColor(Color.WHITE);
        t1.setTextSize(18);
        t1.setTypeface(t1.getTypeface(), Typeface.BOLD);
        int d = Blocker.minutesUntilAllowed(this);
        if (d < 0) {
            t1.setText(label + " is blocked.");
        } else {
            Calendar t = Calendar.getInstance();
            t.add(Calendar.MINUTE, d);
            t.set(Calendar.SECOND, 0);
            t1.setText(label + " is blocked until " + DateFormat.getTimeFormat(this).format(t.getTime()) + ".");
        }
        TextView t2 = new TextView(this);
        t2.setTextColor(Color.parseColor("#9A9A9A"));
        t2.setTextSize(15);
        int n = Blocker.tries(this, pkg);
        t2.setText("You already tried opening it " + n + (n == 1 ? " time." : " times."));
        col.addView(t1);
        col.addView(t2);
        row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row);

        setContentView(root);
    }

    private void goHome() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }

    @Override
    public void onBackPressed() {
        goHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        h.removeCallbacks(watch);
        h.postDelayed(watch, 2000);
    }

    @Override
    protected void onPause() {
        h.removeCallbacks(watch);
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }
}
