package com.mytrade.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class BlockerService extends AccessibilityService {
    private String last = "";
    private long lastLaunch = 0;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            try {
                AccessibilityNodeInfo r = getRootInActiveWindow();
                if (r != null) {
                    CharSequence p = r.getPackageName();
                    if (p != null) observe(p.toString());
                    r.recycle();
                }
            } catch (Exception e) {
                // ignore and try again
            }
            h.postDelayed(this, 800);
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        h.removeCallbacks(tick);
        h.post(tick);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e == null || e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence p = e.getPackageName();
        if (p != null) observe(p.toString());
    }

    private void observe(String pkg) {
        if (pkg.equals("com.android.systemui") || pkg.contains("inputmethod")) return;
        boolean fresh = !pkg.equals(last);
        last = pkg;
        if (pkg.equals(getPackageName())) return;
        if (!Blocker.isBlockedNow(this, pkg)) return;
        if (fresh) Blocker.bumpTries(this, pkg);
        long n = System.currentTimeMillis();
        if (n - lastLaunch < 1200) return;
        lastLaunch = n;
        Intent i = new Intent(this, BlockActivity.class);
        i.putExtra("pkg", pkg);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK
                | Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        startActivity(i);
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(tick);
        super.onDestroy();
    }
}
