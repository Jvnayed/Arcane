package com.mytrade.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;

public class RingService extends Service {
    private MediaPlayer mp;
    private Vibrator vb;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable autoStop = new Runnable() {
        @Override
        public void run() {
            stopForeground(true);
            stopSelf();
        }
    };

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        if (i == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if ("STOP".equals(i.getAction())) {
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        cleanup();

        String name = i.getStringExtra("name");
        String time = i.getStringExtra("time");
        String vibMode = i.getStringExtra("vib");
        int sec = i.getIntExtra("sec", 2);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel("ring", "Alarm ringing", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        ch.enableVibration(false);
        nm.createNotificationChannel(ch);

        Intent ri = new Intent(this, RingActivity.class);
        ri.putExtra("name", name);
        ri.putExtra("time", time);
        ri.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent full = PendingIntent.getActivity(this, 1, ri, fl);
        Intent st = new Intent(this, RingService.class);
        st.setAction("STOP");
        PendingIntent stop = PendingIntent.getService(this, 2, st, fl);

        Notification n = new Notification.Builder(this, "ring")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(name == null ? "Alarm" : name)
                .setContentText(time)
                .setCategory(Notification.CATEGORY_ALARM)
                .setFullScreenIntent(full, true)
                .setContentIntent(full)
                .addAction(0, "Stop", stop)
                .setOngoing(true)
                .build();
        try {
            startForeground(1, n);
        } catch (Exception e) {
            // keep ringing anyway
        }

        try {
            startActivity(ri);
        } catch (Exception e) {
            // the full-screen notification will show it instead
        }

        try {
            vb = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vb != null) {
                vb.vibrate(VibrationEffect.createWaveform(new long[]{0, 700, 500}, 0),
                        new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
            }
        } catch (Exception e) {
            // no vibrator
        }

        long ms = "custom".equals(vibMode) ? Math.max(1, sec) * 1000L : 10 * 60 * 1000L;
        h.postDelayed(autoStop, ms);
        return START_NOT_STICKY;
    }

    private void cleanup() {
        h.removeCallbacks(autoStop);
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
            }
        } catch (Exception e) {
            // ignore
        }
        mp = null;
        try {
            if (vb != null) vb.cancel();
        } catch (Exception e) {
            // ignore
        }
    }

    @Override
    public void onDestroy() {
        cleanup();
        RingActivity.close();
        super.onDestroy();
    }
}
