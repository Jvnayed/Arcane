package com.mytrade.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Locale;

public class Blocker {
    static final String PREF = "blocker_pref";
    static final String KEY = "json";

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    static void save(Context c, String json) {
        sp(c).edit().putString(KEY, json).apply();
    }

    static JSONObject cfg(Context c) {
        try {
            return new JSONObject(sp(c).getString(KEY, "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    static String message(Context c) {
        String m = cfg(c).optString("msg", "").trim();
        if (m.length() == 0) {
            m = "Stay Focused on your GOALS, your PEACE & your HAPPINESS. "
                    + "Don't waste your TIME on anything that doesn't contribute to your GROWTH";
        }
        return m;
    }

    static boolean allowedAt(JSONObject o, int min) {
        JSONArray al = o.optJSONArray("allow");
        if (al == null) return false;
        for (int i = 0; i < al.length(); i++) {
            JSONArray w = al.optJSONArray(i);
            if (w != null && min >= w.optInt(0) && min <= w.optInt(1)) return true;
        }
        return false;
    }

    /** True when this app must be blocked right now. */
    static boolean isBlockedNow(Context c, String pkg) {
        JSONObject o = cfg(c);
        if (!o.optBoolean("on", false)) return false;
        JSONArray apps = o.optJSONArray("apps");
        if (apps == null) return false;
        boolean listed = false;
        for (int i = 0; i < apps.length(); i++) {
            if (pkg.equals(apps.optString(i))) {
                listed = true;
                break;
            }
        }
        if (!listed) return false;
        Calendar n = Calendar.getInstance();
        int dow = (n.get(Calendar.DAY_OF_WEEK) + 5) % 7 + 1; // Mon=1 ... Sun=7
        JSONArray days = o.optJSONArray("days");
        if (days != null) {
            boolean ok = false;
            for (int i = 0; i < days.length(); i++) {
                if (days.optInt(i) == dow) ok = true;
            }
            if (!ok) return false;
        }
        return !allowedAt(o, n.get(Calendar.MINUTE));
    }

    /** Minutes until the next allowed window starts, or -1 if there is none. */
    static int minutesUntilAllowed(Context c) {
        JSONArray al = cfg(c).optJSONArray("allow");
        if (al == null || al.length() == 0) return -1;
        int min = Calendar.getInstance().get(Calendar.MINUTE);
        int best = 999;
        for (int i = 0; i < al.length(); i++) {
            JSONArray w = al.optJSONArray(i);
            if (w == null) continue;
            int s = w.optInt(0);
            int d = s > min ? s - min : s + 60 - min;
            if (d < best) best = d;
        }
        return best == 999 ? -1 : best;
    }

    static String today() {
        Calendar n = Calendar.getInstance();
        return String.format(Locale.US, "%04d%02d%02d", n.get(Calendar.YEAR), n.get(Calendar.MONTH) + 1, n.get(Calendar.DAY_OF_MONTH));
    }

    static int bumpTries(Context c, String pkg) {
        String k = "t_" + pkg + "_" + today();
        int v = sp(c).getInt(k, 0) + 1;
        sp(c).edit().putInt(k, v).apply();
        return v;
    }

    static int tries(Context c, String pkg) {
        return sp(c).getInt("t_" + pkg + "_" + today(), 0);
    }
}
