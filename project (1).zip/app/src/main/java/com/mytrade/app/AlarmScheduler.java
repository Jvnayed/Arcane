package com.mytrade.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AlarmScheduler {
    static final String PREF = "alarms_pref";
    static final String KEY = "json";

    static void save(Context c, String json) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, json).apply();
    }

    static int mins(String s) {
        try {
            String[] p = s.split(":");
            return Integer.parseInt(p[0].trim()) * 60 + Integer.parseInt(p[1].trim());
        } catch (Exception e) {
            return 0;
        }
    }

    static List<Integer> times(JSONObject a) {
        List<Integer> r = new ArrayList<>();
        if ("once".equals(a.optString("mode"))) {
            r.add(mins(a.optString("once", "0:0")));
            return r;
        }
        int s = mins(a.optString("start", "0:0"));
        int e = mins(a.optString("end", "0:0"));
        int iv = Math.max(1, a.optInt("iv", 30));
        for (int m = s; m <= e && r.size() < 300; m += iv) r.add(m);
        return r;
    }

    static boolean matches(JSONObject a, Calendar day) {
        if ("date".equals(a.optString("type"))) {
            String d = String.format(Locale.US, "%04d-%02d-%02d",
                    day.get(Calendar.YEAR), day.get(Calendar.MONTH) + 1, day.get(Calendar.DAY_OF_MONTH));
            return d.equals(a.optString("date"));
        }
        int dow = (day.get(Calendar.DAY_OF_WEEK) + 5) % 7 + 1; // Mon=1 ... Sun=7
        JSONArray ds = a.optJSONArray("days");
        if (ds == null) return false;
        for (int i = 0; i < ds.length(); i++) {
            if (ds.optInt(i) == dow) return true;
        }
        return false;
    }

    /** Finds the next upcoming ring time across all enabled alarms and schedules it. */
    static void scheduleNext(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        String json = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]");
        long now = System.currentTimeMillis() + 1000;
        long best = Long.MAX_VALUE;
        JSONObject bo = null;
        int bm = 0;
        try {
            JSONArray arr = new JSONArray(json);
            for (int k = 0; k < arr.length(); k++) {
                JSONObject a = arr.getJSONObject(k);
                if (!a.optBoolean("on", true)) continue;
                List<Integer> ts = times(a);
                for (int d = 0; d <= 8; d++) {
                    Calendar day = Calendar.getInstance();
                    day.add(Calendar.DAY_OF_YEAR, d);
                    if (!matches(a, day)) continue;
                    for (int m : ts) {
                        Calendar t = (Calendar) day.clone();
                        t.set(Calendar.HOUR_OF_DAY, m / 60);
                        t.set(Calendar.MINUTE, m % 60);
                        t.set(Calendar.SECOND, 0);
                        t.set(Calendar.MILLISECOND, 0);
                        long ms = t.getTimeInMillis();
                        if (ms >= now && ms < best) {
                            best = ms;
                            bo = a;
                            bm = m;
                        }
                    }
                }
            }
        } catch (Exception e) {
            // bad json: nothing to schedule
        }

        Intent in = new Intent(c, AlarmReceiver.class);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        if (bo == null) {
            am.cancel(PendingIntent.getBroadcast(c, 0, in, fl));
            return;
        }
        in.putExtra("name", bo.optString("name", "Alarm"));
        in.putExtra("time", (bm / 60) + ":" + String.format(Locale.US, "%02d", bm % 60));
        in.putExtra("vib", bo.optString("vib", "custom"));
        in.putExtra("sec", bo.optInt("sec", 2));
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, in, fl);
        PendingIntent show = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(best, show), pi);
    }
}
